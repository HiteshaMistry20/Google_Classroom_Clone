@echo off
echo ============================================
echo   Adani Ports - Stock Prediction Dashboard
echo ============================================
echo Dashboard shuru thaay che... please wait!
echo Browser ma automatically open thase.
echo Dashboard band karva mate aa window band karo.
echo ============================================
cd /d "%~dp0"
echo.
echo [1/2] Libraries install thaay che...
python -m pip install -r requirements.txt -q
echo.
echo [2/2] Dashboard start thaay che...
python -m streamlit run app.py
pause
