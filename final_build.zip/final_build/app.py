import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import ensemble
import warnings
warnings.filterwarnings('ignore')

st.set_page_config(
    page_title="Adani Ports — Stock Price Prediction",
    page_icon="📈",
    layout="wide"
)

st.markdown("""
<style>
    .main { background-color: #f5f6fa; }
    .block-container { padding-top: 1.5rem; }
    h2 { color: #1D9E75; border-bottom: 2px solid #1D9E75; padding-bottom: 6px; }
</style>
""", unsafe_allow_html=True)

st.sidebar.title("📈 Adani Ports ML")
st.sidebar.markdown("**Stock Price Prediction**")
st.sidebar.markdown("---")
page = st.sidebar.radio("Navigation", [
    "📊 Overview",
    "📈 Price Charts",
    "🔮 VWAP Predictor",
    "🚀 Future Stock Predictor",
    "🤖 Model Comparison",
    "🔬 Feature Analysis",
    "⚙️ ML Pipeline"
])
st.sidebar.markdown("---")
st.sidebar.markdown("**Dataset:** ADANIPORTS.csv")
st.sidebar.markdown("**Records:** 3,322")
st.sidebar.markdown("**Period:** 2007 – 2021")
st.sidebar.markdown("**Best Model:** XGBoost")

# ── Load Data ─────────────────────────────────────────────────
@st.cache_data
def load_data():
    df = pd.read_csv("ADANIPORTS.csv")
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date').reset_index(drop=True)
    df['Trades'].interpolate(method='linear', inplace=True)
    return df

# ── Train VWAP Models ─────────────────────────────────────────
@st.cache_resource
def train_vwap_models(df):
    cols = ['Prev Close','Open','High','Low','Last','Close','Volume','VWAP']
    clean = df[cols].dropna()
    X = clean[['Prev Close','Open','High','Low','Last','Close','Volume']].values
    y = clean['VWAP'].values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

    lr = LinearRegression()
    lr.fit(X_train, y_train)
    Lr_score = lr.score(X_test, y_test)

    gb = ensemble.GradientBoostingRegressor(n_estimators=400, max_depth=5, min_samples_split=2, learning_rate=0.1)
    gb.fit(X_train, y_train)
    Gboost_score = gb.score(X_test, y_test)

    try:
        from xgboost import XGBRegressor
        xgb = XGBRegressor(verbosity=0)
        xgb.fit(X_train, y_train)
        XGBoost_score = xgb.score(X_test, y_test)
    except:
        xgb = gb
        XGBoost_score = Gboost_score

    y_pred = xgb.predict(X_test)
    return lr, gb, xgb, Lr_score, Gboost_score, XGBoost_score, X_test, y_test, y_pred

# ── Train Future Models ───────────────────────────────────────
@st.cache_resource
def train_future_models(df):
    df_f = df.copy()
    df_f['Next_Close'] = df_f['Close'].shift(-1)
    df_f = df_f.dropna(subset=['Next_Close'])

    cols = ['Prev Close','Open','High','Low','Last','Close','VWAP','Volume']
    clean = df_f[cols + ['Next_Close']].dropna()
    X = clean[cols].values
    y = clean['Next_Close'].values

    X_train_f, X_test_f, y_train_f, y_test_f = train_test_split(X, y, test_size=0.2, random_state=0)

    lr_f = LinearRegression()
    lr_f.fit(X_train_f, y_train_f)
    lr_future_score = lr_f.score(X_test_f, y_test_f)

    gb_f = ensemble.GradientBoostingRegressor(n_estimators=400, max_depth=5, min_samples_split=2, learning_rate=0.1)
    gb_f.fit(X_train_f, y_train_f)
    gb_future_score = gb_f.score(X_test_f, y_test_f)

    try:
        from xgboost import XGBRegressor
        xgb_f = XGBRegressor(verbosity=0)
        xgb_f.fit(X_train_f, y_train_f)
        xgb_future_score = xgb_f.score(X_test_f, y_test_f)
    except:
        xgb_f = gb_f
        xgb_future_score = gb_future_score

    y_pred_f = xgb_f.predict(X_test_f)
    return lr_f, gb_f, xgb_f, lr_future_score, gb_future_score, xgb_future_score, X_test_f, y_test_f, y_pred_f, df_f

# ── Load Everything ───────────────────────────────────────────
try:
    df = load_data()
except FileNotFoundError:
    st.error("ADANIPORTS.csv not found! app.py ni sathe j rakhjo.")
    st.stop()

with st.spinner("Models train thaay che... please wait (1-2 min)"):
    lr, gb, xgb, Lr_score, Gboost_score, XGBoost_score, X_test_v, y_test_v, y_pred_v = train_vwap_models(df)
    lr_f, gb_f, xgb_f, lr_future_score, gb_future_score, xgb_future_score, X_test_f, y_test_f, y_pred_f, df_future = train_future_models(df)

Stockprice_One_Year = df[(df["Date"] > '2011-03-31') & (df["Date"] < '2012-04-01')]
if len(Stockprice_One_Year) == 0:
    Stockprice_One_Year = df.iloc[800:1050]

# ════════════════════════════════════════════════════════════════
# PAGE 1 — OVERVIEW
# ════════════════════════════════════════════════════════════════
if page == "📊 Overview":
    st.title("📊 Adani Ports — Stock Price Prediction Dashboard")
    st.markdown("**VWAP Prediction + Future Close Price Prediction using Machine Learning**")
    st.markdown("---")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Records", f"{len(df):,}", "trading days")
    col2.metric("Avg Close Price", f"Rs {df['Close'].mean():.2f}", f"Max: Rs {df['Close'].max():.2f}")
    col3.metric("VWAP Model R2", f"{XGBoost_score:.4f}", "XGBoost Best")
    col4.metric("Future Close R2", f"{xgb_future_score:.4f}", "XGBoost Best")

    st.markdown("---")
    st.subheader("Close Price vs VWAP — Full Dataset")
    fig, ax = plt.subplots(figsize=(14, 5))
    plt.style.use('fivethirtyeight')
    ax.plot(df['Date'], df['Close'], color='#3A7BD5', linewidth=1, label='Close Price')
    ax.plot(df['Date'], df['VWAP'], color='#1D9E75', linewidth=1, label='VWAP')
    ax.set_xlabel("Date")
    ax.set_ylabel("Price (Rs)")
    ax.legend()
    fig.tight_layout()
    st.pyplot(fig)
    plt.close()

    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("VWAP Model Accuracy")
        fig2, ax2 = plt.subplots(figsize=(7, 4))
        bars = ax2.bar(['Linear Regression', 'Gradient Boosting', 'XGBoost'],
                       [Lr_score, Gboost_score, XGBoost_score],
                       color=['#3A7BD5', '#EF9F27', '#1D9E75'], width=0.5)
        ax2.set_ylim(min([Lr_score, Gboost_score, XGBoost_score]) - 0.005, 1.001)
        ax2.set_ylabel("R2 Score")
        for bar, s in zip(bars, [Lr_score, Gboost_score, XGBoost_score]):
            ax2.text(bar.get_x()+bar.get_width()/2, bar.get_height()-0.003,
                     f'{s:.4f}', ha='center', va='top', color='white', fontweight='bold')
        fig2.tight_layout()
        st.pyplot(fig2)
        plt.close()

    with col2:
        st.subheader("Future Close Model Accuracy")
        fig3, ax3 = plt.subplots(figsize=(7, 4))
        bars2 = ax3.bar(['Linear Regression', 'Gradient Boosting', 'XGBoost'],
                        [lr_future_score, gb_future_score, xgb_future_score],
                        color=['#3A7BD5', '#EF9F27', '#1D9E75'], width=0.5)
        ax3.set_ylim(min([lr_future_score, gb_future_score, xgb_future_score]) - 0.005, 1.001)
        ax3.set_ylabel("R2 Score")
        for bar, s in zip(bars2, [lr_future_score, gb_future_score, xgb_future_score]):
            ax3.text(bar.get_x()+bar.get_width()/2, bar.get_height()-0.003,
                     f'{s:.4f}', ha='center', va='top', color='white', fontweight='bold')
        fig3.tight_layout()
        st.pyplot(fig3)
        plt.close()

    st.markdown("---")
    st.subheader("Dataset Preview")
    st.dataframe(df.head(10), use_container_width=True)

# ════════════════════════════════════════════════════════════════
# PAGE 2 — PRICE CHARTS (exact notebook plots)
# ════════════════════════════════════════════════════════════════
elif page == "📈 Price Charts":
    st.title("📈 Price Charts")
    st.markdown("Exact plots from Jupyter Notebook")
    st.markdown("---")

    # 4.1
    st.subheader("4.1 Stock Comparison — Full Dataset (Green) vs One Year 2011-12 (Red)")
    feature = st.selectbox("Select Feature", ['Prev Close','Open','High','Low','Last','Close','VWAP'])
    fig, ax = plt.subplots(figsize=(14, 5))
    plt.style.use('fivethirtyeight')
    ax.plot(df['Date'], df[feature], c='green', label='Full Dataset')
    ax.plot(Stockprice_One_Year['Date'], Stockprice_One_Year[feature], c='red', label='One Year 2011-12')
    ax.set_xlabel("Date")
    ax.set_ylabel(f"{feature} (Rs)")
    ax.legend()
    st.info(f"**Observation:** One Year 2011-12 {feature} range: Rs {Stockprice_One_Year[feature].min():.2f} to Rs {Stockprice_One_Year[feature].max():.2f}")
    fig.tight_layout()
    st.pyplot(fig)
    plt.close()

    st.markdown("---")

    # 4.2
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("4.2 Without fivethirtyeight style")
        fig2, ax2 = plt.subplots(figsize=(7, 4))
        ax2.plot(df["Open"].values, color='blue')
        ax2.set_ylabel("Open Price (Rs)")
        fig2.tight_layout()
        st.pyplot(fig2)
        plt.close()
    with col2:
        st.subheader("4.2 With fivethirtyeight style")
        fig3, ax3 = plt.subplots(figsize=(7, 4))
        plt.style.use('fivethirtyeight')
        ax3.plot(df["Open"].values)
        ax3.set_ylabel("Open Price (Rs)")
        fig3.tight_layout()
        st.pyplot(fig3)
        plt.close()
    st.info("**Observation:** plt.style.use('fivethirtyeight') gives more clarity in Visualization.")

    st.markdown("---")

    # 4.3 + Missing values
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("4.3 Correlation Heatmap — Pearson")
        corr_df = Stockprice_One_Year.drop(columns=["Date","Symbol","Series"], errors='ignore').select_dtypes(include=[np.number])
        fig4, ax4 = plt.subplots(figsize=(8, 6))
        sns.heatmap(corr_df.corr(method='pearson'), annot=True, fmt='.2f', cmap='Greens', ax=ax4)
        fig4.tight_layout()
        st.pyplot(fig4)
        plt.close()
        st.info("**Observation:** Close, Open, High, Low, VWAP are highly correlated (>0.99).")
    with col2:
        st.subheader("Missing Value Analysis")
        null_counts = df.isnull().sum()
        fig5, ax5 = plt.subplots(figsize=(8, 6))
        null_counts.plot(kind='bar', ax=ax5, color='#3A7BD5')
        ax5.set_ylabel("Null Count")
        plt.xticks(rotation=45)
        fig5.tight_layout()
        st.pyplot(fig5)
        plt.close()

    st.markdown("---")

    # 4.4
    st.subheader("4.4 Multiple Features in Single Plot")
    fig6, ax6 = plt.subplots(figsize=(14, 6))
    plt.style.use('fivethirtyeight')
    soy = Stockprice_One_Year.reset_index(drop=True)
    ax6.plot(soy.index, soy["Low"],   color="r", label="Low")
    ax6.plot(soy.index, soy["High"],  color="g", label="High")
    ax6.plot(soy.index, soy["Close"], color="k", label="Close")
    ax6.plot(soy.index, soy["Open"],  color="b", label="Open")
    ax6.plot(soy.index, soy["Last"],  color="y", label="Last")
    ax6.legend()
    ax6.set_xlabel("Trading Days")
    fig6.tight_layout()
    st.pyplot(fig6)
    plt.close()

    st.markdown("---")

    col1, col2 = st.columns(2)
    with col1:
        # 4.5
        st.subheader("4.5 High-Low Shaded Region")
        fig7, ax7 = plt.subplots(figsize=(7, 5))
        plt.style.use('fivethirtyeight')
        ax7.plot(soy.index, soy["Low"],  color="r", label="Low")
        ax7.plot(soy.index, soy["High"], color="b", label="High")
        ax7.fill_between(soy.index, soy["Low"], soy["High"], color="k", alpha=0.5)
        ax7.legend()
        ax7.set_xlabel("Trading Days")
        fig7.tight_layout()
        st.pyplot(fig7)
        plt.close()

    with col2:
        # 4.6
        st.subheader("4.6 BoxPlot")
        fig8, ax8 = plt.subplots(figsize=(7, 5))
        Stockprice_One_Year[['Close','High','Open','Low','VWAP']].boxplot(ax=ax8)
        fig8.tight_layout()
        st.pyplot(fig8)
        plt.close()

# ════════════════════════════════════════════════════════════════
# PAGE 3 — VWAP PREDICTOR
# ════════════════════════════════════════════════════════════════
elif page == "🔮 VWAP Predictor":
    st.title("🔮 VWAP Predictor")
    st.markdown("Today's VWAP prediction based on stock values")
    st.markdown("---")

    col1, col2 = st.columns([1, 1])
    with col1:
        st.subheader("Select Model")
        mc = st.radio("Model", ["Linear Regression", "Gradient Boosting", "XGBoost"], index=2)
        st.subheader("Enter Today's Values (Rs)")
        prev  = st.number_input("Prev Close", value=float(df['Prev Close'].mean().round(2)), step=0.5)
        opn   = st.number_input("Open",       value=float(df['Open'].mean().round(2)), step=0.5)
        high  = st.number_input("High",       value=float(df['High'].mean().round(2)), step=0.5)
        low   = st.number_input("Low",        value=float(df['Low'].mean().round(2)), step=0.5)
        last  = st.number_input("Last",       value=float(df['Last'].mean().round(2)), step=0.5)
        close = st.number_input("Close",      value=float(df['Close'].mean().round(2)), step=0.5)
        vol   = st.number_input("Volume",     value=int(df['Volume'].mean()), step=1000)
        btn   = st.button("🔮 Predict VWAP", use_container_width=True, type="primary")

    with col2:
        st.subheader("Result")
        if btn:
            inp = np.array([[prev, opn, high, low, last, close, vol]])
            if mc == "Linear Regression":
                pred = lr.predict(inp)[0]; score = Lr_score
            elif mc == "Gradient Boosting":
                pred = gb.predict(inp)[0]; score = Gboost_score
            else:
                pred = xgb.predict(inp)[0]; score = XGBoost_score
            st.success(f"### Predicted VWAP: Rs {pred:.2f}")
            c1, c2 = st.columns(2)
            c1.metric("Model R2", f"{score:.4f}")
            c2.metric("Close Input", f"Rs {close:.2f}")
        else:
            st.info("Enter values and click Predict")

# ════════════════════════════════════════════════════════════════
# PAGE 4 — FUTURE STOCK PREDICTOR
# ════════════════════════════════════════════════════════════════
elif page == "🚀 Future Stock Predictor":
    st.title("🚀 Future Stock Price Predictor")
    st.markdown("**Enter TODAY's values to get TOMORROW's Close Price Prediction**")
    st.markdown("---")

    col1, col2 = st.columns([1, 1])
    with col1:
        st.subheader("Select Model")
        mc_f = st.radio("Model", ["Linear Regression", "Gradient Boosting", "XGBoost"], index=2, key="future_model")

        st.subheader("Enter TODAY's Stock Values (Rs)")
        last_row = df.iloc[-1]
        prev_c  = st.number_input("Prev Close", value=float(round(last_row['Prev Close'], 2)), step=0.5, key="f_prev")
        open_p  = st.number_input("Open",       value=float(round(last_row['Open'], 2)), step=0.5, key="f_open")
        high_p  = st.number_input("High",       value=float(round(last_row['High'], 2)), step=0.5, key="f_high")
        low_p   = st.number_input("Low",        value=float(round(last_row['Low'], 2)), step=0.5, key="f_low")
        last_p  = st.number_input("Last",       value=float(round(last_row['Last'], 2)), step=0.5, key="f_last")
        close_p = st.number_input("Close",      value=float(round(last_row['Close'], 2)), step=0.5, key="f_close")
        vwap_p  = st.number_input("VWAP",       value=float(round(last_row['VWAP'], 2)), step=0.5, key="f_vwap")
        vol_p   = st.number_input("Volume",     value=int(last_row['Volume']), step=1000, key="f_vol")

        fut_btn = st.button("🚀 Predict Tomorrow's Close Price", use_container_width=True, type="primary")

    with col2:
        st.subheader("Tomorrow's Prediction")
        if fut_btn:
            inp_f = np.array([[prev_c, open_p, high_p, low_p, last_p, close_p, vwap_p, vol_p]])

            pred_lr_f  = lr_f.predict(inp_f)[0]
            pred_gb_f  = gb_f.predict(inp_f)[0]
            pred_xgb_f = xgb_f.predict(inp_f)[0]

            if mc_f == "Linear Regression":
                pred_f = pred_lr_f; score_f = lr_future_score
            elif mc_f == "Gradient Boosting":
                pred_f = pred_gb_f; score_f = gb_future_score
            else:
                pred_f = pred_xgb_f; score_f = xgb_future_score

            change = pred_f - close_p
            pct = (change / close_p) * 100
            emoji = "📈" if change >= 0 else "📉"

            st.success(f"### {emoji} Tomorrow's Close: Rs {pred_f:.2f}")
            c1, c2 = st.columns(2)
            c1.metric("Today's Close", f"Rs {close_p:.2f}")
            c2.metric("Tomorrow's Close", f"Rs {pred_f:.2f}",
                      f"{'+' if change >= 0 else ''}{change:.2f} ({pct:.2f}%)")

            st.markdown(f"**Expected Direction: {'UP' if change >= 0 else 'DOWN'}**")
            st.markdown(f"**Model R2 Score: {score_f:.4f}**")

            st.markdown("---")
            st.markdown("**All 3 Models Comparison:**")
            comp = pd.DataFrame({
                'Model': ['Linear Regression', 'Gradient Boosting', 'XGBoost'],
                'Predicted Close (Rs)': [round(pred_lr_f,2), round(pred_gb_f,2), round(pred_xgb_f,2)],
                'Change (Rs)': [round(pred_lr_f-close_p,2), round(pred_gb_f-close_p,2), round(pred_xgb_f-close_p,2)],
                'R2 Score': [round(lr_future_score,4), round(gb_future_score,4), round(xgb_future_score,4)]
            })
            st.dataframe(comp, use_container_width=True, hide_index=True)

            fig, ax = plt.subplots(figsize=(8, 4))
            plt.style.use('fivethirtyeight')
            labels = ['Today Close', 'LR Prediction', 'GB Prediction', 'XGBoost Prediction']
            values = [close_p, pred_lr_f, pred_gb_f, pred_xgb_f]
            colors = ['#888888', '#3A7BD5', '#EF9F27', '#1D9E75']
            bars = ax.bar(labels, values, color=colors, width=0.5)
            ax.set_ylabel("Price (Rs)")
            for bar, v in zip(bars, values):
                ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+1,
                        f'Rs {v:.2f}', ha='center', fontweight='bold', fontsize=9)
            fig.tight_layout()
            st.pyplot(fig)
            plt.close()

            # 30-Day Forecast
            st.markdown("---")
            st.subheader("30-Day Price Forecast")
            pc, op, hp, lp = prev_c, open_p, high_p, low_p
            lsp, cp, vp, vl = last_p, close_p, vwap_p, vol_p
            cur_date = pd.Timestamp(df['Date'].iloc[-1]) + pd.Timedelta(days=1)
            f_prices, f_dates = [], []

            for _ in range(30):
                while cur_date.weekday() >= 5:
                    cur_date += pd.Timedelta(days=1)
                inp_d = np.array([[pc, op, hp, lp, lsp, cp, vp, vl]])
                nxt = float(xgb_f.predict(inp_d)[0])
                f_prices.append(round(nxt, 2))
                f_dates.append(cur_date.date())
                pc, lsp, cp = cp, cp, nxt
                op = nxt * 0.998; hp = nxt * 1.012
                lp = nxt * 0.988; vp = nxt * 1.001
                cur_date += pd.Timedelta(days=1)

            fc_df = pd.DataFrame({'Date': f_dates, 'Predicted Close (Rs)': f_prices})
            hist = df[['Date','Close']].tail(60)

            fig2, ax2 = plt.subplots(figsize=(14, 5))
            plt.style.use('fivethirtyeight')
            ax2.plot(hist['Date'], hist['Close'], color='#3A7BD5', label='Actual (Historical)', linewidth=2)
            ax2.plot(fc_df['Date'], fc_df['Predicted Close (Rs)'],
                     color='red', marker='o', markersize=4,
                     label='Forecast (30 Days)', linewidth=2, linestyle='--')
            ax2.axvline(x=df['Date'].iloc[-1], color='gray', linestyle=':', linewidth=1.5, label='Forecast Start')
            ax2.fill_between(fc_df['Date'],
                             [p*0.97 for p in fc_df['Predicted Close (Rs)']],
                             [p*1.03 for p in fc_df['Predicted Close (Rs)']],
                             alpha=0.15, color='red', label='3% Confidence Band')
            ax2.set_title("30-Day Future Close Price Forecast")
            ax2.set_xlabel("Date")
            ax2.set_ylabel("Price (Rs)")
            ax2.legend()
            plt.xticks(rotation=45)
            fig2.tight_layout()
            st.pyplot(fig2)
            plt.close()

            st.dataframe(fc_df, use_container_width=True, hide_index=True)

        else:
            st.info("Enter today's values and click Predict!")
            st.markdown("**Recent actual data:**")
            st.dataframe(df[['Date','Open','High','Low','Close','VWAP']].tail(5),
                         use_container_width=True, hide_index=True)

        st.markdown("---")
        st.subheader("Actual vs Predicted — Next Day Close (Test Data)")
        fig3, ax3 = plt.subplots(figsize=(8, 4))
        plt.style.use('fivethirtyeight')
        ax3.plot(range(100), y_test_f[:100], color='#3A7BD5', label='Actual', linewidth=1.5)
        ax3.plot(range(100), y_pred_f[:100], color='#E24B4A', label='Predicted', linewidth=1.5, linestyle='--')
        ax3.set_xlabel("Test Samples")
        ax3.set_ylabel("Close Price (Rs)")
        ax3.legend()
        fig3.tight_layout()
        st.pyplot(fig3)
        plt.close()

# ════════════════════════════════════════════════════════════════
# PAGE 5 — MODEL COMPARISON
# ════════════════════════════════════════════════════════════════
elif page == "🤖 Model Comparison":
    st.title("🤖 Model Comparison")
    st.markdown("---")

    st.subheader("VWAP Prediction Accuracy")
    col1, col2, col3 = st.columns(3)
    col1.metric("Linear Regression", f"{Lr_score:.4f}")
    col2.metric("Gradient Boosting", f"{Gboost_score:.4f}")
    col3.metric("XGBoost", f"{XGBoost_score:.4f}", "Best")

    st.markdown("---")
    st.subheader("Future Close Price Prediction Accuracy")
    col1, col2, col3 = st.columns(3)
    col1.metric("Linear Regression", f"{lr_future_score:.4f}")
    col2.metric("Gradient Boosting", f"{gb_future_score:.4f}")
    col3.metric("XGBoost", f"{xgb_future_score:.4f}", "Best")

    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("VWAP — Actual vs Predicted")
        fig, ax = plt.subplots(figsize=(7, 4))
        plt.style.use('fivethirtyeight')
        ax.plot(range(100), y_test_v[:100], color='#3A7BD5', label='Actual', linewidth=1.5)
        ax.plot(range(100), y_pred_v[:100], color='#E24B4A', label='Predicted', linewidth=1.5, linestyle='--')
        ax.legend()
        fig.tight_layout()
        st.pyplot(fig)
        plt.close()

    with col2:
        st.subheader("VWAP Error Distribution")
        fig2, ax2 = plt.subplots(figsize=(7, 4))
        plt.style.use('fivethirtyeight')
        ax2.hist(y_test_v - y_pred_v, bins=50, color='#1D9E75', edgecolor='white', alpha=0.8)
        ax2.axvline(0, color='red', linestyle='--')
        ax2.set_xlabel("Prediction Error")
        fig2.tight_layout()
        st.pyplot(fig2)
        plt.close()

    st.markdown("---")
    st.subheader("Complete Accuracy Summary")
    st.code(f"""
--- VWAP PREDICTION ---
Linear Regression  R2 : {Lr_score:.4f}
Gradient Boosting  R2 : {Gboost_score:.4f}
XGBoost            R2 : {XGBoost_score:.4f}  <- Best

--- NEXT DAY CLOSE PRICE PREDICTION ---
Linear Regression  R2 : {lr_future_score:.4f}
Gradient Boosting  R2 : {gb_future_score:.4f}
XGBoost            R2 : {xgb_future_score:.4f}  <- Best
    """)

# ════════════════════════════════════════════════════════════════
# PAGE 6 — FEATURE ANALYSIS
# ════════════════════════════════════════════════════════════════
elif page == "🔬 Feature Analysis":
    st.title("🔬 Feature Analysis")
    st.markdown("---")

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Correlation Heatmap — 2011-12")
        corr_df = Stockprice_One_Year.drop(columns=["Date","Symbol","Series"], errors='ignore').select_dtypes(include=[np.number])
        fig, ax = plt.subplots(figsize=(8, 6))
        sns.heatmap(corr_df.corr(method='pearson'), annot=True, fmt='.2f', cmap='Greens', ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close()
        st.info("**Observation:** Close, Open, High, Low, VWAP are highly correlated (>0.99). Volume has low correlation.")

    with col2:
        st.subheader("Descriptive Statistics — 2011-12")
        st.dataframe(Stockprice_One_Year.describe().round(2), use_container_width=True)

# ════════════════════════════════════════════════════════════════
# PAGE 7 — ML PIPELINE
# ════════════════════════════════════════════════════════════════
elif page == "⚙️ ML Pipeline":
    st.title("⚙️ ML Pipeline")
    st.markdown("Step-by-step — exact notebook code")
    st.markdown("---")

    steps = [
        ("1", "Import Libraries",
         "import numpy as np\nimport pandas as pd\nimport seaborn as sns\nimport matplotlib.pyplot as plt",
         "NumPy, Pandas, Seaborn, Matplotlib loaded"),
        ("2", "Load Data",
         'df = pd.read_csv("ADANIPORTS.csv")\ndf["Date"] = pd.to_datetime(df["Date"])\ndf = df.sort_values("Date").reset_index(drop=True)',
         f"Shape: {df.shape}"),
        ("3", "Preprocessing",
         "df['Trades'].interpolate(method='linear', inplace=True)\ndf.isna().sum()",
         "Null values handled"),
        ("4", "One Year Sample",
         "Stockprice_One_Year = df[(df['Date']>'2011-03-31')&(df['Date']<'2012-04-01')]",
         f"{len(Stockprice_One_Year)} records"),
        ("5", "Visualization",
         "4.1 Stock Comparison | 4.2 Matplotlib Style\n4.3 Heatmap | 4.4 Multi-Feature | 4.5 fill_between | 4.6 BoxPlot",
         "All charts created"),
        ("6", "Feature Engineering (VWAP)",
         "X = df[['Prev Close','Open','High','Low','Last','Close','Volume']].values\ny = df['VWAP'].values",
         "7 input features, VWAP target"),
        ("7", "Train-Test Split",
         "train_test_split(X, y, test_size=0.2, random_state=0)",
         "80% Train / 20% Test"),
        ("8", "Linear Regression",
         "model = LinearRegression()\nmodel.fit(X_train, y_train)\nLr_score = model.score(X_test, y_test)",
         f"R2 = {Lr_score:.4f}"),
        ("9", "Gradient Boosting",
         "gboost = GradientBoostingRegressor(n_estimators=400, max_depth=5, learning_rate=0.1)\ngboost.fit(X_train, y_train)",
         f"R2 = {Gboost_score:.4f}"),
        ("10", "XGBoost (VWAP)",
         "xgb = XGBRegressor()\nxgb.fit(X_train, y_train)\nXGBoost_score = xgb.score(X_test, y_test)",
         f"R2 = {XGBoost_score:.4f} Best"),
        ("11", "Future Prediction Setup",
         "df_future['Next_Close'] = df['Close'].shift(-1)\nX_future = df[['Prev Close','Open','High','Low','Last','Close','VWAP','Volume']]\ny_future = df_future['Next_Close']",
         "Next day Close as target"),
        ("12", "Future Models Training",
         "lr_future.fit(X_train_f, y_train_f)\ngb_future.fit(X_train_f, y_train_f)\nxgb_future.fit(X_train_f, y_train_f)",
         f"XGBoost R2 = {xgb_future_score:.4f} Best"),
        ("13", "Export All Models",
         "joblib.dump(xgb, 'xgboost_model.pkl')\njoblib.dump(xgb_future, 'xgboost_future_model.pkl')",
         "Models saved!"),
    ]

    for icon, name, code, result in steps:
        with st.expander(f"Step {icon}: {name} — {result}"):
            st.code(code, language='python')

    st.markdown("---")
    st.subheader("Final Accuracy Summary")
    st.code(f"""
VWAP Prediction:
  Linear Regression  : {Lr_score:.4f}
  Gradient Boosting  : {Gboost_score:.4f}
  XGBoost            : {XGBoost_score:.4f}  <- Best

Next Day Close Prediction:
  Linear Regression  : {lr_future_score:.4f}
  Gradient Boosting  : {gb_future_score:.4f}
  XGBoost            : {xgb_future_score:.4f}  <- Best
    """)
